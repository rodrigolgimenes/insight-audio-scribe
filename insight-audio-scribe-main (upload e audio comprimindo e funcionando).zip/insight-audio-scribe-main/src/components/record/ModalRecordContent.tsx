
import React from "react";
import { DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RecordingSection } from "./RecordingSection";

interface ModalRecordContentProps {
  recordingHook: any;
  error: string | null;
  errorDetails: string | null;
}

export function ModalRecordContent({ recordingHook, error, errorDetails }: ModalRecordContentProps) {
  // Create a wrapper for refreshDevices that doesn't return anything
  const handleRefreshDevices = async () => {
    if (recordingHook.refreshDevices) {
      await recordingHook.refreshDevices();
    }
  };

  if (error) {
    return (
      <div className="text-red-500 p-4">
        <p>{error}</p>
        {errorDetails && <pre className="mt-2 text-xs">{errorDetails}</pre>}
      </div>
    );
  }

  return (
    <>
      <DialogHeader>
        <DialogTitle>Record Audio</DialogTitle>
      </DialogHeader>

      <RecordingSection 
        // Pass all recording hook properties as props
        isRecording={recordingHook.isRecording}
        isPaused={recordingHook.isPaused}
        audioUrl={recordingHook.audioUrl}
        mediaStream={recordingHook.mediaStream}
        isSystemAudio={recordingHook.isSystemAudio}
        handleStartRecording={recordingHook.handleStartRecording}
        handleStopRecording={recordingHook.handleStopRecording}
        handlePauseRecording={recordingHook.handlePauseRecording}
        handleResumeRecording={recordingHook.handleResumeRecording}
        handleDelete={recordingHook.handleDelete}
        onSystemAudioChange={recordingHook.setIsSystemAudio}
        audioDevices={recordingHook.audioDevices || []}
        selectedDeviceId={recordingHook.selectedDeviceId}
        onDeviceSelect={recordingHook.setSelectedDeviceId}
        deviceSelectionReady={recordingHook.deviceSelectionReady}
        showPlayButton={true}
        showDeleteButton={true}
        lastAction={recordingHook.lastAction}
        onRefreshDevices={handleRefreshDevices}
        devicesLoading={recordingHook.devicesLoading}
        permissionState={recordingHook.permissionState}
      />
    </>
  );
}
